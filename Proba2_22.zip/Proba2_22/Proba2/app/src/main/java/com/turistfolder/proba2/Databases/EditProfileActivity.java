package com.turistfolder.proba2.Databases;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.content.Intent;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.turistfolder.proba2.R;
import com.turistfolder.proba2.User.HomePage;

public class EditProfileActivity extends AppCompatActivity {

    // creating variables for EditText and buttons.
    EditText nameEditText, surnameEditText, emailEditText, usernameEditText;
    Button btnUpdate;

    // creating a variable for our Firebase Database.
    FirebaseDatabase firebaseDatabase;
    // creating a variable for our Database Reference for Firebase.
    DatabaseReference databaseReference;


    String nameUser, surnameUser, emailUser, usernameUser;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_profile);

        // below line is used to get the instance of our Firebase database.
        firebaseDatabase = FirebaseDatabase.getInstance();
        // below line is used to get reference for our database.
        databaseReference = firebaseDatabase.getReference("UserInfo");

        // hooks
        nameEditText = findViewById(R.id.editName);
        surnameEditText = findViewById(R.id.editSurname);
        emailEditText = findViewById(R.id.editEmail);
        usernameEditText = findViewById(R.id.editUsername);
        btnUpdate = findViewById(R.id.update_button);

        showUserData();

        btnUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isDataInCorrectForm()) {
                    int flag = 0;
                    if (isNameChanged()) flag++;
                    if (isSurnameChanged()) flag++;
                    if (isEmailChanged()) flag++;
                    if (isUsernameChanged()) flag++;
                    if (flag > 0) {
                        Toast.makeText(EditProfileActivity.this, "Saved", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(EditProfileActivity.this, "No Changes Found", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(EditProfileActivity.this, "Data is incorrect", Toast.LENGTH_SHORT).show();
                }
            }
        });


    }

    public void callHomepage(View view){

        startActivity(new Intent(getApplicationContext() , HomePage.class));

    }

    public void callBackButton(View view)
    {
        onBackPressed();
    }

    private boolean isNameChanged() {
        if (!nameUser.equals(nameEditText.getText().toString())) {
            databaseReference.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child("name").setValue(nameEditText.getText().toString());
            nameUser = nameEditText.getText().toString();
            return true;
        } else {
            return false;
        }
    }

    private boolean isSurnameChanged() {
        if (!surnameUser.equals(surnameEditText.getText().toString())) {
            databaseReference.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child("surname").setValue(surnameEditText.getText().toString());
            surnameUser = surnameEditText.getText().toString();
            return true;
        } else {
            return false;
        }
    }

    private boolean isEmailChanged() {
        if (!emailUser.equals(emailEditText.getText().toString())) {
            databaseReference.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child("email").setValue(emailEditText.getText().toString());
            emailUser = emailEditText.getText().toString();
            return true;
        } else {
            return false;
        }
    }

    private boolean isUsernameChanged() {
        if (!usernameUser.equals(usernameEditText.getText().toString())) {
            databaseReference.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child("username").setValue(usernameEditText.getText().toString());
            usernameUser = usernameEditText.getText().toString();
            return true;
        } else {
            return false;
        }
    }

    private boolean isDataInCorrectForm() {
        if (nameEditText.getText().toString().isEmpty()) {
            nameEditText.setError("Name can not be empty");
            nameEditText.requestFocus();
            return false;
        }
        if (surnameEditText.getText().toString().isEmpty()) {
            surnameEditText.setError("Surname can not be empty");
            surnameEditText.requestFocus();
            return false;
        }
        if (emailEditText.getText().toString().isEmpty()) {
            emailEditText.setError("Email can not be empty");
            emailEditText.requestFocus();
            return false;
        }
        if (!Patterns.EMAIL_ADDRESS.matcher(emailEditText.getText().toString()).matches()) { //da provjerimo je li upisan valjani email
            emailEditText.setError("Please provide valid email");
            emailEditText.requestFocus();
            return false;
        }
        if (usernameEditText.getText().toString().isEmpty()) {
            usernameEditText.setError("Username can not be empty");
            usernameEditText.requestFocus();
            return false;
        }

        return true;
    }

    public void showUserData() {
        Intent intent = getIntent();
        nameUser = intent.getStringExtra("name"); // ovo i 4 linije ispod su prvotno dobavljeni podaci iz baze
        surnameUser = intent.getStringExtra("surname");
        emailUser = intent.getStringExtra("email");
        usernameUser = intent.getStringExtra("username");

        nameEditText.setText(nameUser);
        surnameEditText.setText(surnameUser);
        emailEditText.setText(emailUser);
        usernameEditText.setText(usernameUser);
    }
}