package com.turistfolder.proba2.Common;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;

//dodaje Ivor/Ivana
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

import com.turistfolder.proba2.Databases.ViewFavouritesActivity;
import com.turistfolder.proba2.Databases.ViewProfileActivity;
import com.turistfolder.proba2.R;
import com.turistfolder.proba2.User.HomePage;

public class LoginActivity extends AppCompatActivity {

    private FirebaseAuth mAuth;
    private EditText email, password;
    private Button btnLogin;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //fullscreen
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_login);

        //u varijablu textView spremamo plavi logo
        TextView textView = findViewById(R.id.plavi_logo);
        String text = "TouriST";
        //postavjamo nasu varijablu wordToSpan da ima vridnost naseg teksta
        SpannableString wordToSpan = new SpannableString(text);
        //postavljamo varijablu fcsYellow da bude zute boje
        ForegroundColorSpan fcsYellow=new ForegroundColorSpan(Color.YELLOW);
        //posavljamo zutu boju od 5. do 7. mista  nase rici
        wordToSpan.setSpan(fcsYellow, 5 , 7 , Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        //posttavljamo to na nasu riv u textView
        textView.setText(wordToSpan);

        mAuth = FirebaseAuth.getInstance();
        email = findViewById(R.id.textInputEditEmail);
        password = findViewById(R.id.textInputEditPassword);
        btnLogin = findViewById(R.id.login_button);
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                login();
            }
        });

    }

    public void callLogInOrRegister(View view){

        startActivity(new Intent(getApplicationContext(),LoginOrRegister.class));
    }

    //dodat funkciju u kojoj se pritrazuje baza kad kliknemo na sign in
    //public void LogIn
    private void login(){
        String user = email.getText().toString().trim();
        String pass = password.getText().toString().trim();
        if(user.isEmpty())
        {
            email.setError("Email can not be empty");
        }
        if(pass.isEmpty())
        {
            password.setError("Password can not be empty");
        }
        else
        {
            mAuth.signInWithEmailAndPassword(user,pass).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task)
                {
                    if(task.isSuccessful())
                    {
                        Toast.makeText(LoginActivity.this, "Sign In Successful", Toast.LENGTH_SHORT).show();
                        //startActivity(new Intent(LoginActivity.this , HomePage.class));
                        startActivity(new Intent(getApplicationContext(), HomePage.class));
                    }
                    else
                    {
                        Toast.makeText(LoginActivity.this, "Sign In Failed - "+task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }
    }



}

