package com.turistfolder.proba2.Databases;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.ActivityOptions;
import android.content.Intent;
import android.os.Bundle;
import android.util.Pair;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.turistfolder.proba2.Common.SplashScreen;
import com.turistfolder.proba2.R;
import com.turistfolder.proba2.User.HomePage;

public class ViewProfileActivity extends AppCompatActivity {



    // creating variables for EditText and buttons.
    private TextView nameTextView, surnameTextView, usernameTextView, emailTextView;
    private TextView fullNameLabel, usernameLabel;
    private Button btnEditProfile, btnLogOut;

    // creating a variable for our Firebase Database.
    FirebaseDatabase firebaseDatabase;
    // creating a variable for our Database Reference for Firebase.
    DatabaseReference databaseReference;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_profile);

        // initializing our edittext and button + za auth      aka 'Hooks'
        nameTextView = findViewById(R.id.name_profile);
        surnameTextView = findViewById(R.id.surname_profile);
        emailTextView = findViewById(R.id.email_profile);
        usernameTextView = findViewById(R.id.username_profile);
        fullNameLabel = findViewById(R.id.full_name_label);
        usernameLabel = findViewById(R.id.username_label);
        btnEditProfile =findViewById(R.id.edit_profile_button);
        btnLogOut = findViewById(R.id.logout_button);

        //show all user data
        showAllUserData();

        btnEditProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { callEditProfile(v);}
        });

        btnLogOut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FirebaseAuth.getInstance().signOut();
                Toast.makeText(ViewProfileActivity.this, "Logout successful", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(getApplicationContext(), SplashScreen.class));
            }
        });


    }
    public void callEditProfile(View view){

        Intent intent =new Intent(getApplicationContext(), EditProfileActivity.class);
        //dodajemo animaciju tako da kad kliknemo na login se "otvori" na prethodnom ekranu
        //[1] koliko elemenata zelimo da bude animirano
        Pair[] pairs = new Pair[1];
        //[0] na pvoj poziciji
        pairs[0]= new Pair<View,String>(btnEditProfile,"transition_edit_profile");
        //prije koristeno-> startActivity(new Intent(getApplicationContext(),LoginActivity.class));

        ActivityOptions options = ActivityOptions.makeSceneTransitionAnimation(ViewProfileActivity.this,pairs);

        intent.putExtra("name", nameTextView.getText());
        intent.putExtra("surname", surnameTextView.getText());
        intent.putExtra("email", emailTextView.getText());
        intent.putExtra("username", usernameTextView.getText());

        startActivity(intent,options.toBundle());

    }

    private void showAllUserData() {

        // below line is used to get the instance of our Firebase database.
        firebaseDatabase = FirebaseDatabase.getInstance();
        // below line is used to get reference for our database.
        databaseReference = firebaseDatabase.getReference("UserInfo");

        databaseReference.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DataSnapshot> task) {
                if(task.isSuccessful()){

                    if(task.getResult().exists()){

                        Toast.makeText(ViewProfileActivity.this, "Successfully Read", Toast.LENGTH_SHORT).show();
                        DataSnapshot dataSnapshot = task.getResult();
                        String nameFromDB = dataSnapshot.child("name").getValue(String.class);
                        String surnameFromDB = dataSnapshot.child("surname").getValue(String.class);
                        String usernameFromDB = dataSnapshot.child("username").getValue(String.class);
                        String emailFromDB = dataSnapshot.child("email").getValue(String.class);

                        nameTextView.setText(nameFromDB);
                        surnameTextView.setText(surnameFromDB);
                        emailTextView.setText(emailFromDB);
                        usernameTextView.setText(usernameFromDB);
                        usernameLabel.setText("@"+usernameFromDB);
                        fullNameLabel.setText(nameFromDB+" "+surnameFromDB);

                    }
                    else{
                        Toast.makeText(ViewProfileActivity.this, "User Doesn't Exist", Toast.LENGTH_SHORT).show();
                    }

                }
                else{
                    Toast.makeText(ViewProfileActivity.this, "Failed to read data", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    public void callHomepage(View view){

        startActivity(new Intent(getApplicationContext() , HomePage.class));

    }

    public void callBackButton(View view)
    {
        onBackPressed();
    }
}