package com.turistfolder.proba2.Databases;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.turistfolder.proba2.R;
import com.turistfolder.proba2.User.HomePage;

import java.util.ArrayList;
import java.util.List;


public class FavouritesAdapter extends RecyclerView.Adapter<MyViewHolder> {


    public Context context;
    List<ItemClass> dataList = new ArrayList<>();

    public FavouritesAdapter(Context context, List<ItemClass> dataList) {
        this.context = context;
        this.dataList = dataList;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.recycler_favourites, parent, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        //Glide.with(context).load(dataList.get(position).getDataImageRes()).into(holder.recImage);
            Integer res = dataList.get(position).getDataImageRes();
            String title = dataList.get(position).getDataTitle();
            holder.recImage.setImageResource(res);
            holder.recTitle.setText(title);

            //Class originalClass = dataList.get(position).getClass();

            holder.recCard.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent = new Intent(context, HomePage.class);
                    context.startActivity(intent);
                }
            });

    }

    @Override
    public int getItemCount() {
        return dataList.size();
    }
}

class MyViewHolder extends RecyclerView.ViewHolder {
        ImageView recImage;
        TextView recTitle;
        CardView recCard;

        public MyViewHolder(@NonNull View itemView){
            super(itemView);

            recImage = itemView.findViewById(R.id.recImage);
            recCard = itemView.findViewById(R.id.recCard);
            recTitle = itemView.findViewById(R.id.recTitle);
        }

}

