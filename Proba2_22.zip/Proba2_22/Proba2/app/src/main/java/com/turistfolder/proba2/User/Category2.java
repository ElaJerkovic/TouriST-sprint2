package com.turistfolder.proba2.User;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.turistfolder.proba2.R;

public class Category2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_category2);

        RelativeLayout menu1_bar = findViewById(R.id.menu1_bar);
        menu1_bar.setAlpha(0.7F);

        TextView textView = findViewById(R.id.logo);
        String text = "TouriST";
        SpannableString wordToSpan = new SpannableString(text);
        ForegroundColorSpan fcsYellow=new ForegroundColorSpan(Color.YELLOW);
        wordToSpan.setSpan(fcsYellow, 5 , 7 , Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        textView.setText(wordToSpan);
    }

    public void callSquare1(View view){

        startActivity(new Intent(getApplicationContext() , Slider6.class));

    }

    public void callSquare2(View view){

        startActivity(new Intent(getApplicationContext() , Slider7.class));

    }

    public void callSquare3(View view){

        startActivity(new Intent(getApplicationContext() , Slider8.class));

    }

    public void callSquare4(View view){

        startActivity(new Intent(getApplicationContext() , Slider10.class));

    }

    public void callSquare5(View view){

        startActivity(new Intent(getApplicationContext() , Slider9.class));

    }

    public void callListOfCategories(View view){

        startActivity(new Intent(getApplicationContext() ,ListOfCategories.class));
    }

    public void callHomepage(View view){

        startActivity(new Intent(getApplicationContext() , HomePage.class));

    }

}