package com.turistfolder.proba2.Databases;

public class ItemClass {
    private String dataTitle;
    private Integer dataImageRes;
    private String key;

    public void setDataTitle(String dataTitle) {
        this.dataTitle = dataTitle;
    }

    public void setDataImageRes(Integer dataImageRes) {
        this.dataImageRes = dataImageRes;
    }

    private Class classOriginal;

    public Class getClassOriginal() {
        return classOriginal;
    }

    public void setClassOriginal(Class classOriginal) {
        this.classOriginal = classOriginal;
    }


    public String getKey() {
        return key;
    }
    public void setKey(String key) {
        this.key = key;
    }
    public String getDataTitle() {
        return dataTitle;
    }

    public Integer getDataImageRes() {
        return dataImageRes;
    }

    public ItemClass(String dataTitle, Integer dataImageRes, Class classOriginal) {
        this.dataTitle = dataTitle;
        this.dataImageRes = dataImageRes;
        this.classOriginal = classOriginal;
    }

    public ItemClass(){
    }
}
