package com.turistfolder.proba2.User;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.turistfolder.proba2.R;

public class ListOfCategories extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_of_categories);

        RelativeLayout menu1_bar = findViewById(R.id.menu1_bar);
        menu1_bar.setAlpha(0.7F);

        TextView textView = findViewById(R.id.logo);
        String text = "TouriST";
        SpannableString wordToSpan = new SpannableString(text);
        ForegroundColorSpan fcsYellow=new ForegroundColorSpan(Color.YELLOW);
        wordToSpan.setSpan(fcsYellow, 5 , 7 , Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        textView.setText(wordToSpan);


    }

    public void callCategory1(View view){

        startActivity(new Intent(getApplicationContext() , Category1.class));

    }

    public void callCategory2(View view){

        startActivity(new Intent(getApplicationContext() , Category2.class));

    }

    public void callCategory3(View view){

        startActivity(new Intent(getApplicationContext() , Category3.class));

    }

    public void callCategory4(View view){

        startActivity(new Intent(getApplicationContext() , Category4.class));

    }

    public void callCategory5(View view){

        startActivity(new Intent(getApplicationContext() , Category5.class));

    }

    public void callMenu(View view){

        startActivity(new Intent(getApplicationContext() , HomePage.class));

    }

    public void callHomepage(View view){

        startActivity(new Intent(getApplicationContext() , HomePage.class));

    }
}