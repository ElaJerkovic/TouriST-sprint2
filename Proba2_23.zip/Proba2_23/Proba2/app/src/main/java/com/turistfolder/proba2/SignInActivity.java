package com.turistfolder.proba2;

import android.app.Activity;

public class SignInActivity extends Activity {
}
