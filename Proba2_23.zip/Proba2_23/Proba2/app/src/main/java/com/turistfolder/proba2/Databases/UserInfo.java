package com.turistfolder.proba2.Databases;

public class UserInfo {

    // string variable for
    // storing user name
    private String name;

    // string variable for storing
    // user surname
    private String surname;

    // string variable for storing
    // user email.
    private String email;

    // string variable for storing
    // user username.
    private String username;

    // an empty constructor is
    // required when using
    // Firebase Realtime Database.
    public UserInfo() {

    }

    // created getter and setter methods
    // for all our variables.
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }
}

