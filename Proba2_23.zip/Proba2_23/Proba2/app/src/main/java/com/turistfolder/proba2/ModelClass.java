package com.turistfolder.proba2;

public class ModelClass {
    String monumentsName;
    int img;

    public String getMonumentsName() {
        return monumentsName;
    }

    public void setMonumentsName(String monumentsName) {
        this.monumentsName = monumentsName;
    }

    public int getImg() {
        return img;
    }

    public void setImg(int img) {
        this.img = img;
    }
}
