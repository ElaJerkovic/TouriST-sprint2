package com.turistfolder.proba2.Common;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ActivityOptions;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.util.Pair;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;


import com.turistfolder.proba2.R;

public class LoginOrRegister extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //fullscreen
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_login_or_register);

        //u varijablu textView spremamo plavi logo
        TextView textView = findViewById(R.id.plavi_logo);
        String text = "TouriST";
        //postavjamo nasu varijablu wordToSpan da ima vridnost naseg teksta
        SpannableString wordToSpan = new SpannableString(text);
        //postavljamo varijablu fcsYellow da bude zute boje
        ForegroundColorSpan fcsYellow=new ForegroundColorSpan(Color.YELLOW);
        //posavljamo zutu boju od 5. do 7. mista  nase rici
        wordToSpan.setSpan(fcsYellow, 5 , 7 , Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        //posttavljamo to na nasu riv u textView
        textView.setText(wordToSpan);


    }

    //ova funkcija se poziva kad se samo kad korisnik klikne na log in
    public void callLogIn(View view){

        Intent intent =new Intent(getApplicationContext(),LoginActivity.class);
        //dodajemo animaciju tako da kad kliknemo na login se "otvori" na prethodnom ekranu
        //[1] koliko elemenata zelimo da bude animirano
        Pair[] pairs = new Pair[1];
        //[0] na pvoj poziciji
        pairs[0]= new Pair<View,String>(findViewById(R.id.signin_button),"transition_signin");
        //prije koristeno-> startActivity(new Intent(getApplicationContext(),LoginActivity.class));

        ActivityOptions options = ActivityOptions.makeSceneTransitionAnimation(LoginOrRegister.this,pairs);
        startActivity(intent,options.toBundle());

    }

    //pribacujemo na ekran sign in
    public void callRegister(View view){

        Intent intent =new Intent(getApplicationContext(), RegisterActivity.class);
        //dodajemo animaciju tako da kad kliknemo na login se "otvori" na prethodnom ekranu
        //[1] koliko elemenata zelimo da bude animirano
        Pair[] pairs = new Pair[1];
        //[0] na pvoj poziciji
        pairs[0]= new Pair<View,String>(findViewById(R.id.signup_button),"transition_signup");
        //prije koristeno->startActivity(new Intent(getApplicationContext(),RegisterActivity.class));

        ActivityOptions options = ActivityOptions.makeSceneTransitionAnimation(LoginOrRegister.this,pairs);
        startActivity(intent,options.toBundle());
    }

}

