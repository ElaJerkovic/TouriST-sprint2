package com.turistfolder.proba2.User;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.viewpager.widget.ViewPager;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.turistfolder.proba2.Databases.ViewFavouritesActivity;
import com.turistfolder.proba2.MyAdapter;
import com.turistfolder.proba2.R;

import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.List;

public class Slider10 extends AppCompatActivity {

    ViewPager viewPager;

    LinearLayout sliderDotspanel;
    private int dotscount;
    private ImageView[] dots;

//za favorite
    FloatingActionButton btnFloatingHeart;
    boolean isInMyFavourites = false;
    private TextView titleTextView;
    private String title;
    private Integer imageRes;
    //kraj za favorite

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_slider10);

       /* RelativeLayout relative_layout = findViewById(R.id.relative_layout);
        relative_layout.setAlpha(0.4F);*/

       /* RelativeLayout menu_bar = findViewById(R.id.menu_bar);
        menu_bar.setAlpha(0.7F);*/

       /* ScrollView scroll_view=findViewById(R.id.scroll_view);
        scroll_view.setAlpha(1.0F);*/

        RelativeLayout menu1_bar = findViewById(R.id.menu1_bar);
        menu1_bar.setAlpha(0.7F);

        /*TextView description = findViewById(R.id.FirstText);
        description.setAlpha(0.5F);*/

        TextView textView = findViewById(R.id.logo);
        String text = "TouriST";
        SpannableString wordToSpan = new SpannableString(text);
        ForegroundColorSpan fcsYellow=new ForegroundColorSpan(Color.YELLOW);
        wordToSpan.setSpan(fcsYellow, 5 , 7 , Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        textView.setText(wordToSpan);

        viewPager=findViewById(R.id.viewPager1);

        sliderDotspanel=(LinearLayout)  findViewById(R.id.SliderDots);

        List<Integer> imageList=new ArrayList<>();
        imageList.add(R.drawable.znamenitost10_01);
        imageList.add(R.drawable.znamenitost10_02);
        imageList.add(R.drawable.znamenitost10_03);
        imageList.add(R.drawable.znamenitost10_04);

        MyAdapter myAdapter=new MyAdapter(imageList);
        viewPager.setAdapter(myAdapter);

        dotscount=myAdapter.getCount();
        dots=new ImageView[dotscount];

        for(int i = 0; i < dotscount; i++){

            dots[i] = new ImageView(this);
            dots[i].setImageDrawable(ContextCompat.getDrawable(getApplicationContext(), R.drawable.non_active_dot));

            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);

            params.setMargins(8, 0, 8, 0);

            sliderDotspanel.addView(dots[i], params);

        }

        dots[0].setImageDrawable(ContextCompat.getDrawable(getApplicationContext(), R.drawable.active_dot));

        viewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {

                for(int i = 0; i< dotscount; i++){
                    dots[i].setImageDrawable(ContextCompat.getDrawable(getApplicationContext(), R.drawable.non_active_dot));
                }

                dots[position].setImageDrawable(ContextCompat.getDrawable(getApplicationContext(), R.drawable.active_dot));

            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });

        btnFloatingHeart = findViewById(R.id.floating_heart);
        titleTextView = findViewById(R.id.title);
        title = titleTextView.getText().toString();
        imageRes = imageList.get(0);

        if(FirebaseAuth.getInstance().getCurrentUser() != null){
            //Toast.makeText(Slider1.this, "You are here", Toast.LENGTH_SHORT).show();

            checkIsFavourite();

            //Toast.makeText(Slider1.this, "you are out", Toast.LENGTH_SHORT).show();

        }
        //Toast.makeText(Slider1.this, "you go on", Toast.LENGTH_SHORT).show();

        btnFloatingHeart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(isInMyFavourites){
                    ViewFavouritesActivity favClass = new ViewFavouritesActivity();
                    favClass.removeFromFavourites("Slider10"); //ovim u zagradama, kao argument ćemo funkciji poslat string "Slider1"
                    //this.getClass().getEnclosingClass().getSimpleName()
                }
                else{
                    ViewFavouritesActivity favClass = new ViewFavouritesActivity();
                    favClass.addToFavourites("Slider10", title, imageRes, Slider10.class); //ovim u zagradama, kao argument ćemo funkciji poslat string "Slider1"
                }
                //Toast.makeText(Slider1.this, "You have clicked on the floating button", Toast.LENGTH_SHORT).show();
            }
        });

    }


    public void callHomepage(View view){

        startActivity(new Intent(getApplicationContext() , HomePage.class));

    }

    public void callBackButton(View view)
    {
        onBackPressed();
    }

    public void checkIsFavourite(){

        //String itemId= this.getClass().getSimpleName();
        FirebaseDatabase firebaseDatabase = FirebaseDatabase.getInstance();
        DatabaseReference databaseReference = firebaseDatabase.getReference("UserInfo");
        databaseReference.child(FirebaseAuth.getInstance().getUid()).child("Favourites").child("Slider10")
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        isInMyFavourites = snapshot.exists();
                        if(isInMyFavourites){
                            //is already in "favourites"
                            //Toast.makeText(Slider1.this, "it is favourited", Toast.LENGTH_SHORT).show();

                            btnFloatingHeart.setImageDrawable((getDrawable(R.drawable.ic_baseline_favorite_24)));
                        }
                        else{
                            //is not in "favourites"
                            //Toast.makeText(Slider1.this, "it is not favourited", Toast.LENGTH_SHORT).show();

                            btnFloatingHeart.setImageDrawable(getDrawable(R.drawable.ic_baseline_favorite_border_24));
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
    }
}