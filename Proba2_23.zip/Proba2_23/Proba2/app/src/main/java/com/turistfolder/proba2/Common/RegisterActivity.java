package com.turistfolder.proba2.Common;

import android.content.Intent;
import android.graphics.Color;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.view.WindowManager;
import android.widget.TextView;

import android.os.Bundle;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import com.turistfolder.proba2.Databases.UserInfo;
import com.turistfolder.proba2.R;
import com.turistfolder.proba2.User.HomePage;

public class RegisterActivity extends AppCompatActivity {

    //autentifikacija
    private FirebaseAuth mAuth;
    //kraj autentifikacije

    // creating variables for EditText and buttons.
    private EditText nameEditText, surnameEditText, emailEditText, usernameEditText, passwordEditText; //potrebno za auth
    private Button btnRegister;

    // creating a variable for our Firebase Database.
    FirebaseDatabase firebaseDatabase;

    // creating a variable for our Database Reference for Firebase.
    DatabaseReference databaseReference;

    // creating a variable for our object class
    UserInfo userInfo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //fullscreen
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_register);

        //u varijablu textView spremamo plavi logo
        TextView textView = findViewById(R.id.plavi_logo);
        String text = "TouriST";
        //postavjamo nasu varijablu wordToSpan da ima vridnost naseg teksta
        SpannableString wordToSpan = new SpannableString(text);
        //postavljamo varijablu fcsYellow da bude zute boje
        ForegroundColorSpan fcsYellow=new ForegroundColorSpan(Color.YELLOW);
        //posavljamo zutu boju od 5. do 7. mista  nase rici
        wordToSpan.setSpan(fcsYellow, 5 , 7 , Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        //posttavljamo to na nasu riv u textView
        textView.setText(wordToSpan);

        //autentifikacija
        mAuth = FirebaseAuth.getInstance();
        //kraj autentifikacije

        // initializing our edittext and button + za auth      aka 'Hooks'
        nameEditText = findViewById(R.id.textInputEditName);
        surnameEditText = findViewById(R.id.textInputEditSurname);
        emailEditText = findViewById(R.id.textInputEditEmail);
        usernameEditText = findViewById(R.id.textInputEditUsername);
        passwordEditText = findViewById(R.id.textInputEditPassword);

        // below line is used to get the instance of our Firebase database.
        firebaseDatabase = FirebaseDatabase.getInstance();

        // below line is used to get reference for our database.
        databaseReference = firebaseDatabase.getReference("UserInfo");

        // initializing our object
        // class variable.
        userInfo = new UserInfo();

        btnRegister = findViewById(R.id.register_button);

        // adding on click listener for our button.
        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Register();
            }
        });
    }

    private void addDatatoFirebase(String name, String surname, String email, String username) {
        // below 3 lines of code is used to set
        // data in our object class.
        userInfo.setName(name);
        userInfo.setSurname(surname);
        userInfo.setEmail(email);
        userInfo.setUsername(username);

        // we are use add value event listener method
        // which is called with database reference.
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                // inside the method of on Data change we are setting
                // our object class to our database reference.
                // data base reference will sends data to firebase.
                //linija ispod omogucuje da se stvaraju zasebni useri svaki put, a ne da se prebrise
                databaseReference.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).setValue(userInfo);

                // after adding this data we are showing toast message.
                //Toast.makeText(RegisterActivity.this, "data added", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                // if the data is not added or it is cancelled then
                // we are displaying a failure toast message.
                //Toast.makeText(RegisterActivity.this, "Fail to add data " + error, Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void Register(){


        // getting text from our edittext fields. + za auth
        String name = nameEditText.getText().toString();
        String surname = surnameEditText.getText().toString();
        String email = emailEditText.getText().toString();
        String username = usernameEditText.getText().toString();
        String password = passwordEditText.getText().toString();

        // below line is for checking whether the
        // edittext fields are empty or not.
               /* if (TextUtils.isEmpty(name) && TextUtils.isEmpty(surname) && TextUtils.isEmpty(email) && TextUtils.isEmpty(username) && TextUtils.isEmpty(password)) {
                    // if the text fields are empty
                    // then show the below message.
                    Toast.makeText(RegisterActivity.this, "Please add some data.", Toast.LENGTH_SHORT).show();
                }*/
        if(TextUtils.isEmpty(name)) {
            nameEditText.setError("Name is required");
            nameEditText.requestFocus();
            return;
        }
        if(TextUtils.isEmpty(surname)) {
            surnameEditText.setError("Surname is required");
            surnameEditText.requestFocus();
            return;
        }
        if(TextUtils.isEmpty(email)) {
            emailEditText.setError("Email is required");
            emailEditText.requestFocus();
            return;
        }
        if(!Patterns.EMAIL_ADDRESS.matcher(email).matches()) { //da provjerimo je li upisan valjani email
            emailEditText.setError("Please provide valid email");
            emailEditText.requestFocus();
            return;
        }
        if(TextUtils.isEmpty(username)) {
            usernameEditText.setError("Username is required");
            usernameEditText.requestFocus();
            return;
        }
        if(TextUtils.isEmpty(password)) {
            passwordEditText.setError("Password is required");
            passwordEditText.requestFocus();
            return;
        }
        if(password.length()<6) {
            passwordEditText.setError("Password should be at least 6 characters long");
            passwordEditText.requestFocus();
            return;
        }
        // provjerili smo sve, pa cemo ovdje uci tek kad sve bude ispostovano
        // spremamo ove valjane podatke u nasu bazu
        //autentifikacija
        mAuth.createUserWithEmailAndPassword(email, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if(task.isSuccessful()){
                    addDatatoFirebase(name, surname, email, username); //ne triba password jer password necemo dodavat u bazu
                    Toast.makeText(RegisterActivity.this, "User has been registered successfully!", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(getApplicationContext(), HomePage.class));
                }
                else{
                    Toast.makeText(RegisterActivity.this, "Failed to register!", Toast.LENGTH_SHORT).show();
                }

            }
        });

        //kraj autentifikacije
    }

    public void callLogInOrRegister(View view){

        startActivity(new Intent(getApplicationContext(),LoginOrRegister.class));
    }


}