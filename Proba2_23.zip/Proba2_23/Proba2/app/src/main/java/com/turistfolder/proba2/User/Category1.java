package com.turistfolder.proba2.User;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.turistfolder.proba2.R;

public class Category1 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_category1);


        RelativeLayout menu1_bar = findViewById(R.id.menu1_bar);
        menu1_bar.setAlpha(0.7F);

        TextView textView = findViewById(R.id.logo);
        String text = "TouriST";
        SpannableString wordToSpan = new SpannableString(text);
        ForegroundColorSpan fcsYellow=new ForegroundColorSpan(Color.YELLOW);
        wordToSpan.setSpan(fcsYellow, 5 , 7 , Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        textView.setText(wordToSpan);
    }

    public void callChurch1(View view){

        startActivity(new Intent(getApplicationContext() , Slider1.class));

    }

    public void callChurch2(View view){

        startActivity(new Intent(getApplicationContext() , Slider2.class));

    }

    public void callChurch3(View view){

        startActivity(new Intent(getApplicationContext() , Slider3.class));

    }

    public void callChurch4(View view){

        startActivity(new Intent(getApplicationContext() , Slider4.class));

    }

    public void callChurch5(View view){

        startActivity(new Intent(getApplicationContext() , Slider5.class));

    }

    public void callListOfCategories(View view){

        startActivity(new Intent(getApplicationContext() ,ListOfCategories.class));

    }

    public void callHomepage(View view){

        startActivity(new Intent(getApplicationContext() , HomePage.class));

    }

}