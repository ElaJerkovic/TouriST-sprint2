package com.turistfolder.proba2.Common;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;

import com.turistfolder.proba2.R;

public class SplashScreen extends AppCompatActivity {

    private static int SPLASH_TIMER=5000; //koliko triba da se pirbaci na sljedeci "zaslon"
    //Varijable kojima dodajemo animaciu (nama je to ikona TouriST)
    ImageView icon;

    //Animations
    Animation sideAnim, bottomAnim;

    @Override //ovo se koristi kad child class koristi metode deklarirane od parent klase
    protected void onCreate(Bundle savedInstanceState) {
        //When we override a method, we have the option of completely replacing the method in our class,
        // or of extending the existing parent class' method. By calling super.onCreate(savedInstanceState);
        // you tell the Dalvik VM to run your code in addition to the existing code in the onCreate() of the parent class.
        // If you leave out this line, then only your code is run. The existing code is ignored completely.
        super.onCreate(savedInstanceState);

        //mislin da ovo zadrzi da je priko cilog ekrana
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.splash_screen);

        //Hooks
        icon=findViewById(R.id.ikona);

        //animation
        sideAnim= AnimationUtils.loadAnimation(this,R.anim.side_anim);
        bottomAnim= AnimationUtils.loadAnimation(this,R.anim.bottom_anim);

        //set Animations on elements
        icon.setAnimation(sideAnim);
        icon.setAnimation(bottomAnim);

        //pribacivanje nakon nekog vrimena na sljedecu stranicu
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent intent = new Intent(getApplicationContext(),LoginOrRegister.class); //SplashScreen.this
                startActivity(intent);
                finish();
            }
        },SPLASH_TIMER);

    }
}