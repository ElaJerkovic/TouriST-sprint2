package com.turistfolder.proba2.Databases;

import static java.lang.Integer.parseInt;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.turistfolder.proba2.MyAdapter;
import com.turistfolder.proba2.R;
import com.turistfolder.proba2.User.HomePage;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class ViewFavouritesActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    List<ItemClass> dataList;
    DatabaseReference databaseReference;
    ValueEventListener eventListener;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_favourites);

        //Toast.makeText(ViewFavouritesActivity.this, "one", Toast.LENGTH_LONG).show();


        recyclerView = findViewById(R.id.recyclerFav);
        //GridLayoutManager gridLayoutManager = new GridLayoutManager(ViewFavouritesActivity.this, 1);
        //recyclerView.setLayoutManager(gridLayoutManager);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        //Toast.makeText(ViewFavouritesActivity.this, "two", Toast.LENGTH_LONG).show();

        //AlertDialog.Builder builder = new AlertDialog.Builder(ViewFavouritesActivity.this);
        //builder.setCancelable(false);
        //builder.setView(R.layout.recycler_favourites);
        //AlertDialog dialog = builder.create();
        //dialog.show();

        //Toast.makeText(ViewFavouritesActivity.this, "three", Toast.LENGTH_LONG).show();

        dataList = new ArrayList<ItemClass>();

        FavouritesAdapter adapter = new FavouritesAdapter(ViewFavouritesActivity.this, dataList);
        recyclerView.setAdapter(adapter);

        //Toast.makeText(ViewFavouritesActivity.this, "four", Toast.LENGTH_LONG).show();

        databaseReference = FirebaseDatabase.getInstance().getReference("UserInfo").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child("Favourites");
        //dialog.show();

        eventListener = databaseReference.addValueEventListener(new ValueEventListener() {
            @SuppressLint("NotifyDataSetChanged")
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                dataList.clear();
                int i =0;
                for(DataSnapshot itemSnapshot : snapshot.getChildren()){

                    //Toast.makeText(ViewFavouritesActivity.this, "five"+itemSnapshot.getKey(), Toast.LENGTH_LONG).show();

                    ItemClass itemClass = itemSnapshot.getValue(ItemClass.class);

                    itemClass.setKey(itemSnapshot.getKey());
                    itemClass.setClassOriginal(itemSnapshot.child("class").getValue().getClass());
                    itemClass.setDataImageRes(parseInt(itemSnapshot.child("imageResource").getValue().toString()));
                    itemClass.setDataTitle(itemSnapshot.child("itemTitle").getValue().toString());

                    dataList.add(itemClass);

                }
                adapter.notifyDataSetChanged();
                //dialog.dismiss();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

                //dialog.dismiss();
            }
        });


    }

    public void addToFavourites(String itemId, String itemTitle, Integer imageResource, Class classWhereItWasAdded){

        long timestamp = System.currentTimeMillis();
        HashMap<String, Object> hashMap = new HashMap<>();
        hashMap.put("itemId", ""+itemId);
        hashMap.put("timestamp", ""+timestamp);
        hashMap.put("itemTitle", ""+itemTitle);
        hashMap.put("imageResource", ""+imageResource);
        hashMap.put("class", ""+classWhereItWasAdded);

        FirebaseDatabase firebaseDatabase = FirebaseDatabase.getInstance();
        DatabaseReference databaseReference = firebaseDatabase.getReference("UserInfo");
        databaseReference.child(FirebaseAuth.getInstance().getUid()).child("Favourites").child(itemId)
                .setValue(hashMap)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {}
                });
    }



    public void removeFromFavourites(String itemId) {

        FirebaseDatabase firebaseDatabase = FirebaseDatabase.getInstance();
        DatabaseReference databaseReference = firebaseDatabase.getReference("UserInfo");
        databaseReference.child(FirebaseAuth.getInstance().getUid()).child("Favourites").child(itemId).removeValue()
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {}
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {}
                });
    }


    public void callBackButton(View view)
    {
        onBackPressed();
    }

    public void callHomepage(View view){

        startActivity(new Intent(getApplicationContext() , HomePage.class));

    }
}