package com.turistfolder.proba2.User;

import androidx.activity.result.ActivityResultLauncher;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.ActivityOptions;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.graphics.Color;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;

import android.util.Pair;
import android.view.MenuItem;
import android.view.WindowManager;
import android.widget.TextView;

import com.journeyapps.barcodescanner.ScanContract;
import com.journeyapps.barcodescanner.ScanOptions;
import com.turistfolder.proba2.Databases.ViewProfileActivity;
import com.turistfolder.proba2.SearchActivity;
import com.turistfolder.proba2.R;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.navigation.NavigationView;
import android.content.Intent;
import android.graphics.drawable.GradientDrawable;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;


public class HomePage extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {


    LinearLayout contentView;
    ImageView qr_scan;
    ImageView menuIcon;
    DrawerLayout drawerLayout;
    NavigationView navigationView;
    static final float END_SCALE = 0.8f;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_home_page);

        TextView textView = findViewById(R.id.logo);
        String text = "TouriST";
        SpannableString wordToSpan = new SpannableString(text);
        ForegroundColorSpan fcsYellow=new ForegroundColorSpan(Color.YELLOW);
        wordToSpan.setSpan(fcsYellow, 5 , 7 , Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        textView.setText(wordToSpan);

        //menu hooks
        drawerLayout = findViewById(R.id.drawer_layout);
        navigationView = findViewById(R.id.navigation_view);

        menuIcon = findViewById(R.id.menu_icon);
        contentView = findViewById(R.id.content);

        navigationDrawer();

        //qr scanner
        qr_scan = findViewById(R.id.menu1_icon);
        qr_scan.setOnClickListener(v->
        {
            scanCode();
        });
    }

    private void scanCode()
    {
        ScanOptions options = new ScanOptions();
        options.setBeepEnabled(true);
        options.setOrientationLocked(true);
        options.setCaptureActivity(CaptureAct.class);
        barLauncher.launch(options);
    }

    ActivityResultLauncher<ScanOptions> barLauncher = registerForActivityResult(new ScanContract(), result ->
    {
        if(result.getContents() != null)
        {
            AlertDialog.Builder builder = new AlertDialog.Builder(HomePage.this);
            builder.setTitle("Result");
            builder.setMessage(result.getContents());
            builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    dialogInterface.dismiss();
                }
            }).show();
        }
    });

    //funkcije za izbornik
    private void navigationDrawer() {
        //nav drawer
        navigationView.bringToFront();
        navigationView.setNavigationItemSelectedListener(this::onNavigationItemSelected);
        //navigationView.setCheckedItem(R.id.nav_home);

        //botun za izbornik
        menuIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(drawerLayout.isDrawerVisible(GravityCompat.START)) drawerLayout.closeDrawer(GravityCompat.START);
                else drawerLayout.openDrawer(GravityCompat.START);//ako nije otvoren otvori ga
            }
        });

        animateNavigationDrawer();
    }

    private void animateNavigationDrawer() {
        drawerLayout.setScrimColor(getResources().getColor(R.color.transparent));//da poplavi hp kad otvoris izbornik
        drawerLayout.addDrawerListener(new DrawerLayout.SimpleDrawerListener() {
            @Override
            public void onDrawerSlide(View drawerView, float slideOffset) {

                // Scale the View based on current slide offset
                final float diffScaledOffset = slideOffset * (1 - END_SCALE);
                final float offsetScale = 1 - diffScaledOffset;
                contentView.setScaleX(offsetScale);// da se homepage mice kad se mice i izbornik
                contentView.setScaleY(offsetScale);

                // Translate the View, accounting for the scaled width
                final float xOffset = drawerView.getWidth() * slideOffset;
                final float xOffsetDiff = contentView.getWidth() * diffScaledOffset / 2;
                final float xTranslation = xOffset - xOffsetDiff;
                contentView.setTranslationX(xTranslation);
            }
        });
    }
    @Override
    public void onBackPressed() {
        if(drawerLayout.isDrawerVisible(GravityCompat.START)){
            drawerLayout.closeDrawer(GravityCompat.START);
        }
        else super.onBackPressed();
    }
    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        return true;
    }


    public void callViewProfile(MenuItem item) // dodala san onClick="callViewProfile" u main_menu.xml u item di je id=nav_profile ali ne valja-ivana
    {
        startActivity(new Intent(getApplicationContext() , ViewProfileActivity.class));
    }

    public void callViewCategories(MenuItem item){
        startActivity(new Intent(getApplicationContext() , ListOfCategories.class));
    }

    public void callSearchBar(MenuItem item){
        startActivity(new Intent(getApplicationContext() , SearchActivity.class));
    }

    public void callHome(MenuItem item)
    {
        startActivity(new Intent(getApplicationContext(), HomePage.class));
    }

    public void callChurch1(View view){

        startActivity(new Intent(getApplicationContext() , Slider1.class));

    }

    public void callChurch2(View view){

        startActivity(new Intent(getApplicationContext() , Slider2.class));

    }

    public void callChurch3(View view){

        startActivity(new Intent(getApplicationContext() , Slider3.class));

    }

    public void callChurch4(View view){

        startActivity(new Intent(getApplicationContext() , Slider4.class));

    }

    public void callChurch5(View view){

        startActivity(new Intent(getApplicationContext() , Slider5.class));

    }

    public void callSquare1(View view){

        startActivity(new Intent(getApplicationContext() , Slider6.class));

    }

    public void callSquare2(View view){

        startActivity(new Intent(getApplicationContext() , Slider7.class));

    }

    public void callSquare3(View view){

        startActivity(new Intent(getApplicationContext() , Slider8.class));

    }

    public void callSquare4(View view){

        startActivity(new Intent(getApplicationContext() , Slider9.class));

    }

    public void callSquare5(View view){

        startActivity(new Intent(getApplicationContext() , Slider10.class));

    }

    public void callStatue1(View view){

        startActivity(new Intent(getApplicationContext() , Slider11.class));

    }

    public void callStatue2(View view){

        startActivity(new Intent(getApplicationContext() , Slider12.class));

    }

    public void callStatue3(View view){

        startActivity(new Intent(getApplicationContext() , Slider13.class));

    }

    public void callStatue4(View view){

        startActivity(new Intent(getApplicationContext() , Slider14.class));

    }

    public void callFountain1(View view){

        startActivity(new Intent(getApplicationContext() , Slider15.class));

    }

    public void callFountain2(View view){

        startActivity(new Intent(getApplicationContext() , Slider16.class));

    }

    public void callPark1(View view){

        startActivity(new Intent(getApplicationContext() , Slider17.class));

    }

    public void callPark2(View view){

        startActivity(new Intent(getApplicationContext() , Slider18.class));

    }

    public void callPark3(View view){

        startActivity(new Intent(getApplicationContext() , Slider19.class));

    }

    public void callPark4(View view){

        startActivity(new Intent(getApplicationContext() , Slider20.class));

    }
}