package com.turistfolder.proba2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.turistfolder.proba2.User.HomePage;

import java.util.ArrayList;

public class SearchActivity extends AppCompatActivity {

    SearchView searchView;
    RecyclerView recyclerView;
    ArrayList<ModelClass> arrayList = new ArrayList<>();
    ArrayList<ModelClass> searchList;
    String[] monumentsList = new String[]{"Cathedral of Saint Domnius", "Church of Saint Jerome", "Church and Monastery of St. Francis",
     "Church of St. Nicholas", "Church of Holy Trinity", "Pjaca", "Voćni trg (Fruit Square)", "Prokurative", "Šperun", "Peristil",
            "Statue of Marko Marulić", "Statue of Gregory Nin", "Statue of Emanuel Vidović","Sphinx" };
    int[] imgList = new int[]{R.drawable.crkva1, R.drawable.crkva2, R.drawable.crkva3, R.drawable.crkva4, R.drawable.crkva5,
            R.drawable.trg1, R.drawable.trg2, R.drawable.trg3, R.drawable.trg4, R.drawable.trg5,
            R.drawable.kip1, R.drawable.kip2, R.drawable.kip3, R.drawable.kip4};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);
        recyclerView = findViewById(R.id.recyclerView);
        searchView = findViewById(R.id.searchView);

        for (int i = 0; i < monumentsList.length; i++){
            ModelClass modelClass = new ModelClass();
            modelClass.setMonumentsName(monumentsList[i]);
            modelClass.setImg(imgList[i]);
            arrayList.add(modelClass);
        }

        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(SearchActivity.this);
        recyclerView.setLayoutManager(layoutManager);

        MonumentAdapter monumentAdapter = new MonumentAdapter(SearchActivity.this, arrayList);
        recyclerView.setAdapter(monumentAdapter);

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                searchList = new ArrayList<>();

                if(query.length() > 0){
                    for (int i  = 0; i < arrayList.size(); i++){
                        if(arrayList.get(i).getMonumentsName().toUpperCase().contains(query.toUpperCase())){
                            ModelClass modelClass = new ModelClass();
                            modelClass.setMonumentsName(arrayList.get(i).getMonumentsName());
                            modelClass.setImg(arrayList.get(i).getImg());
                            searchList.add(modelClass);
                        }
                    }

                    RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(SearchActivity.this);
                    recyclerView.setLayoutManager(layoutManager);

                    MonumentAdapter monumentAdapter = new MonumentAdapter(SearchActivity.this, searchList);
                    recyclerView.setAdapter(monumentAdapter);
                }
                else {
                    RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(SearchActivity.this);
                    recyclerView.setLayoutManager(layoutManager);

                    MonumentAdapter monumentAdapter = new MonumentAdapter(SearchActivity.this, arrayList);
                    recyclerView.setAdapter(monumentAdapter);
                }

                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                searchList = new ArrayList<>();

                if(newText.length() > 0){
                    for (int i  = 0; i < arrayList.size(); i++){
                        if(arrayList.get(i).getMonumentsName().toUpperCase().contains(newText.toUpperCase())){
                            ModelClass modelClass = new ModelClass();
                            modelClass.setMonumentsName(arrayList.get(i).getMonumentsName());
                            modelClass.setImg(arrayList.get(i).getImg());
                            searchList.add(modelClass);
                        }
                    }

                    RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(SearchActivity.this);
                    recyclerView.setLayoutManager(layoutManager);

                    MonumentAdapter monumentAdapter = new MonumentAdapter(SearchActivity.this, searchList);
                    recyclerView.setAdapter(monumentAdapter);
                }
                else {
                    RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(SearchActivity.this);
                    recyclerView.setLayoutManager(layoutManager);

                    MonumentAdapter monumentAdapter = new MonumentAdapter(SearchActivity.this, arrayList);
                    recyclerView.setAdapter(monumentAdapter);
                }
                return false;
            }
        });
    }

    public void callHomepage(View view){

        startActivity(new Intent(getApplicationContext() , HomePage.class));

    }
}