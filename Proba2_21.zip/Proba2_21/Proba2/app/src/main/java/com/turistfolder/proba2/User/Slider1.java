package com.turistfolder.proba2.User;

import android.net.Uri;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.viewpager.widget.ViewPager;

import com.turistfolder.proba2.MyAdapter;
import com.turistfolder.proba2.R;

import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.List;

public class Slider1 extends AppCompatActivity {




    ViewPager viewPager;

    LinearLayout sliderDotspanel;
    private int dotscount;
    private ImageView[] dots;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_slider1);

       /* RelativeLayout relative_layout = findViewById(R.id.relative_layout);
        relative_layout.setAlpha(0.4F);*/

       /* RelativeLayout menu_bar = findViewById(R.id.menu_bar);
        menu_bar.setAlpha(0.7F);*/

       /* ScrollView scroll_view=findViewById(R.id.scroll_view);
        scroll_view.setAlpha(1.0F);*/

        RelativeLayout menu1_bar = findViewById(R.id.menu1_bar);
        menu1_bar.setAlpha(0.7F);

        /*TextView description = findViewById(R.id.FirstText);
        description.setAlpha(0.5F);*/

        TextView textView = findViewById(R.id.logo);
        String text = "TouriST";
        SpannableString wordToSpan = new SpannableString(text);
        ForegroundColorSpan fcsYellow=new ForegroundColorSpan(Color.YELLOW);
        wordToSpan.setSpan(fcsYellow, 5 , 7 , Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        textView.setText(wordToSpan);

        viewPager=findViewById(R.id.viewPager1);

        sliderDotspanel=(LinearLayout)  findViewById(R.id.SliderDots);

        List<Integer> imageList=new ArrayList<>();
        imageList.add(R.drawable.znamenitost1_01);
        imageList.add(R.drawable.znamenitost1);
        imageList.add(R.drawable.znamenitost1_02);
        imageList.add(R.drawable.znamenitost1_03);

        MyAdapter myAdapter=new MyAdapter(imageList);
        viewPager.setAdapter(myAdapter);

        dotscount=myAdapter.getCount();
        dots=new ImageView[dotscount];

        for(int i = 0; i < dotscount; i++){

            dots[i] = new ImageView(this);
            dots[i].setImageDrawable(ContextCompat.getDrawable(getApplicationContext(), R.drawable.non_active_dot));

            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);

            params.setMargins(8, 0, 8, 0);

            sliderDotspanel.addView(dots[i], params);

        }

        dots[0].setImageDrawable(ContextCompat.getDrawable(getApplicationContext(), R.drawable.active_dot));

        viewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {

                for(int i = 0; i< dotscount; i++){
                    dots[i].setImageDrawable(ContextCompat.getDrawable(getApplicationContext(), R.drawable.non_active_dot));
                }

                dots[position].setImageDrawable(ContextCompat.getDrawable(getApplicationContext(), R.drawable.active_dot));

            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });

    }


    public void callHomepage(View view){

        startActivity(new Intent(getApplicationContext() , HomePage.class));

    }

    public void callCategory1(View view){

        startActivity(new Intent(getApplicationContext() , Category1.class));

    }

    public void openGoogleMap(View view) {
        Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://goo.gl/maps/qcoguUwQbKJS7pq59"));
        startActivity(browserIntent);
    }


}