package com.turistfolder.proba2;

public interface RecyclerViewInterface {
    void onItemClick(int position);
}
